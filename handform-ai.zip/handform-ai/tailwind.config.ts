import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14171A",
        paper: "#FBF9F4",
        graphite: "#3C4247",
        line: "#D8D2C4",
        signal: "#2E5D50",
        flag: "#B54834",
        haze: "#EFEAE0"
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
        mono: ["var(--font-mono)"]
      }
    }
  },
  plugins: []
};
export default config;
