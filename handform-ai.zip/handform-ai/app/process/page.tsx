"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Nav } from "@/components/ui/Nav";
import { useFormSession } from "@/hooks/useFormSession";
import { enhanceImage } from "@/lib/image-processing/enhance";
import { ProcessingStage } from "@/types/form";

const STAGES: ProcessingStage[] = [
  { id: "detect", label: "Document detected", status: "pending" },
  { id: "enhance", label: "Image enhanced", status: "pending" },
  { id: "layout", label: "Layout analyzed", status: "pending" },
  { id: "handwriting", label: "English handwriting recognized", status: "pending" },
  { id: "fields", label: "Fields detected", status: "pending" },
  { id: "understand", label: "Form understood", status: "pending" },
  { id: "reconstruct", label: "Digital form generated", status: "pending" },
  { id: "validate", label: "Form validated", status: "pending" }
];

export default function ProcessPage() {
  const router = useRouter();
  const started = useRef(false);
  const {
    originalImage,
    setEnhancedImage,
    setSchema,
    setValidation,
    setStages,
    stages
  } = useFormSession();
  const [error, setError] = useState<string | null>(null);
  const [local, setLocal] = useState<ProcessingStage[]>(STAGES);

  useEffect(() => {
    if (!originalImage) {
      router.replace("/scan");
      return;
    }
    if (started.current) return;
    started.current = true;
    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [originalImage]);

  function mark(id: ProcessingStage["id"], status: ProcessingStage["status"]) {
    setLocal((prev) => {
      const next = prev.map((s) => (s.id === id ? { ...s, status } : s));
      setStages(next);
      return next;
    });
  }

  async function run() {
    try {
      mark("detect", "active");
      await sleep(300);
      mark("detect", "done");

      mark("enhance", "active");
      const enhanced = await enhanceImage(originalImage!);
      setEnhancedImage(enhanced.enhancedDataUrl);
      mark("enhance", "done");

      mark("layout", "active");
      const res = await fetch("/api/reconstruct", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ imageDataUrl: enhanced.enhancedDataUrl })
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error ?? "Processing failed");
      mark("layout", "done");

      mark("handwriting", "active");
      await sleep(200);
      mark("handwriting", "done");

      mark("fields", "active");
      await sleep(200);
      mark("fields", "done");

      mark("understand", "active");
      await sleep(200);
      mark("understand", "done");

      mark("reconstruct", "done" as const);
      setSchema(body.schema);

      mark("validate", "active");
      setValidation(body.validation);
      mark("validate", "done");

      await sleep(400);
      router.push("/review");
    } catch {
      setError(
        "The form could not be reconstructed. Please try again with a clearer photo."
      );
    }
  }

  return (
    <main>
      <Nav />
      <div className="mx-auto max-w-lg px-6 py-16">
        <h1 className="font-display text-2xl">Reading your form</h1>
        <p className="mt-2 text-sm text-graphite">
          The Form Reconstruction Agent is working through each stage below.
        </p>

        <ul className="mt-8 space-y-3">
          {local.map((s) => (
            <li key={s.id} className="flex items-center gap-3 text-sm">
              <span
                className={`flex h-5 w-5 items-center justify-center rounded-full text-xs ${
                  s.status === "done"
                    ? "bg-signal text-paper"
                    : s.status === "active"
                    ? "border border-signal text-signal"
                    : "border border-line text-line"
                }`}
              >
                {s.status === "done" ? "✓" : ""}
              </span>
              <span className={s.status === "pending" ? "text-graphite/60" : "text-ink"}>
                {s.label}
              </span>
            </li>
          ))}
        </ul>

        {error && (
          <div className="mt-8 rounded-lg bg-flag/10 px-4 py-3 text-sm text-flag">
            {error}
          </div>
        )}
      </div>
    </main>
  );
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
