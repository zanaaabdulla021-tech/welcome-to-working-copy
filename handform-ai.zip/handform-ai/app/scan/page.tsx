"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Nav } from "@/components/ui/Nav";
import { UploadDropzone } from "@/components/scanner/UploadDropzone";
import { CameraScanner } from "@/components/scanner/CameraScanner";
import { useFormSession } from "@/hooks/useFormSession";

export default function ScanPage() {
  const [tab, setTab] = useState<"upload" | "camera">("upload");
  const [error, setError] = useState<string | null>(null);
  const { setOriginalImage, reset } = useFormSession();
  const router = useRouter();

  function handleImage(dataUrl: string) {
    reset();
    setOriginalImage(dataUrl);
    router.push("/process");
  }

  return (
    <main>
      <Nav />
      <div className="mx-auto max-w-2xl px-6 py-14">
        <h1 className="font-display text-3xl">Scan a form</h1>
        <p className="mt-2 text-graphite">
          Upload a photo or PDF, or use your camera as a document scanner.
        </p>

        <div className="mt-8 flex gap-2 border-b border-line">
          {(["upload", "camera"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`-mb-px border-b-2 px-4 py-2 text-sm capitalize ${
                tab === t ? "border-ink text-ink" : "border-transparent text-graphite"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {tab === "upload" ? (
            <UploadDropzone onImageReady={handleImage} onError={setError} />
          ) : (
            <CameraScanner onCapture={handleImage} onError={setError} />
          )}
        </div>

        {error && (
          <p className="mt-4 rounded-lg bg-flag/10 px-4 py-3 text-sm text-flag">
            {error}
          </p>
        )}
      </div>
    </main>
  );
}
