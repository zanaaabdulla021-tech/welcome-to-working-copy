"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Nav } from "@/components/ui/Nav";
import { useFormSession } from "@/hooks/useFormSession";
import { CompareView } from "@/components/review/CompareView";
import { runFormReconstructionAgent } from "@/lib/agents/formReconstructionAgent";

export default function ReviewPage() {
  const router = useRouter();
  const { schema, enhancedImage, originalImage, updateField, setSchema, setValidation } =
    useFormSession();
  const [retrying, setRetrying] = useState<string | null>(null);
  const image = enhancedImage ?? originalImage;

  useEffect(() => {
    if (!schema || !image) router.replace("/scan");
  }, [schema, image, router]);

  if (!schema || !image) return null;

  const needsReview = schema.pages
    .flatMap((p) => p.fields)
    .filter((f) => f.needsReview);

  async function retryField(fieldId: string) {
    if (!image) return;
    setRetrying(fieldId);
    try {
      const result = await runFormReconstructionAgent(image);
      const refreshed = result.schema.pages
        .flatMap((p) => p.fields)
        .find((f) => f.label === schema!.pages.flatMap((p) => p.fields).find((x) => x.id === fieldId)?.label);
      if (refreshed) {
        updateField(fieldId, { value: refreshed.value, confidence: refreshed.confidence });
      }
      setValidation(result.validation);
    } finally {
      setRetrying(null);
    }
  }

  return (
    <main>
      <Nav />
      <div className="mx-auto max-w-4xl px-6 py-14">
        <h1 className="font-display text-3xl">{schema.title}</h1>
        <p className="mt-2 text-graphite">
          {needsReview.length === 0
            ? "Everything was read with high confidence."
            : `${needsReview.length} field${needsReview.length > 1 ? "s" : ""} need a quick look.`}
        </p>

        {needsReview.length > 0 && (
          <div className="mt-8 space-y-4">
            {needsReview.map((f) => (
              <div key={f.id} className="rounded-xl border border-flag/40 bg-flag/5 p-4">
                <div className="flex items-center justify-between">
                  <p className="font-medium">{f.label}</p>
                  <span className="text-xs text-flag">
                    {Math.round(f.confidence * 100)}% confidence
                  </span>
                </div>
                <p className="mt-1 font-mono text-sm text-graphite">
                  {f.value ?? "— unreadable —"}
                </p>
                <div className="mt-3 flex items-center gap-3">
                  <input
                    defaultValue={f.value ?? ""}
                    placeholder="Type the correct value"
                    onBlur={(e) => updateField(f.id, { value: e.target.value })}
                    className="w-full rounded-md border border-line px-3 py-1.5 text-sm"
                  />
                  <button
                    onClick={() => updateField(f.id, {})}
                    className="whitespace-nowrap rounded-full bg-ink px-4 py-1.5 text-xs text-paper"
                  >
                    Accept
                  </button>
                  <button
                    disabled={retrying === f.id}
                    onClick={() => retryField(f.id)}
                    className="whitespace-nowrap rounded-full border border-line px-4 py-1.5 text-xs disabled:opacity-40"
                  >
                    {retrying === f.id ? "Retrying…" : "Retry"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-12">
          <h2 className="font-display text-xl">Original vs. digital</h2>
          <div className="mt-4">
            <CompareView image={image} schema={schema} />
          </div>
        </div>

        <div className="mt-10 flex gap-3">
          <button
            onClick={() => router.push("/editor")}
            className="rounded-full bg-ink px-6 py-3 text-sm text-paper hover:bg-graphite"
          >
            Open in editor
          </button>
          <button
            onClick={() => router.push("/preview")}
            className="rounded-full border border-line px-6 py-3 text-sm hover:border-ink"
          >
            Skip to export
          </button>
        </div>
      </div>
    </main>
  );
}
