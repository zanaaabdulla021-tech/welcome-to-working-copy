"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { v4 as uuid } from "uuid";
import { Nav } from "@/components/ui/Nav";
import { useFormSession } from "@/hooks/useFormSession";
import { FormField, FieldType } from "@/types/form";

const FIELD_TYPES: FieldType[] = [
  "text",
  "textarea",
  "number",
  "email",
  "phone",
  "date",
  "time",
  "checkbox",
  "radio",
  "select",
  "signature"
];

export default function EditorPage() {
  const router = useRouter();
  const { schema, setSchema } = useFormSession();
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => {
    if (!schema) router.replace("/scan");
  }, [schema, router]);

  if (!schema) return null;
  const page = schema.pages[0];

  function patchField(id: string, patch: Partial<FormField>) {
    setSchema({
      ...schema!,
      updatedAt: new Date().toISOString(),
      pages: schema!.pages.map((p) => ({
        ...p,
        fields: p.fields.map((f) => (f.id === id ? { ...f, ...patch } : f))
      }))
    });
  }

  function addField() {
    const newField: FormField = {
      id: uuid(),
      label: "New field",
      type: "text",
      value: "",
      confidence: 1,
      required: false,
      position: { x: 80, y: 40, width: 300, height: 50 }
    };
    setSchema({
      ...schema!,
      pages: schema!.pages.map((p, i) =>
        i === 0 ? { ...p, fields: [...p.fields, newField] } : p
      )
    });
    setSelected(newField.id);
  }

  function duplicateField(id: string) {
    const field = page.fields.find((f) => f.id === id);
    if (!field) return;
    const copy = { ...field, id: uuid(), position: { ...field.position, y: field.position.y + 60 } };
    setSchema({
      ...schema!,
      pages: schema!.pages.map((p, i) =>
        i === 0 ? { ...p, fields: [...p.fields, copy] } : p
      )
    });
  }

  function removeField(id: string) {
    setSchema({
      ...schema!,
      pages: schema!.pages.map((p) => ({
        ...p,
        fields: p.fields.filter((f) => f.id !== id)
      }))
    });
    if (selected === id) setSelected(null);
  }

  function reorder(id: string, dir: -1 | 1) {
    const idx = page.fields.findIndex((f) => f.id === id);
    const target = idx + dir;
    if (target < 0 || target >= page.fields.length) return;
    const fields = [...page.fields];
    [fields[idx], fields[target]] = [fields[target], fields[idx]];
    setSchema({
      ...schema!,
      pages: schema!.pages.map((p, i) => (i === 0 ? { ...p, fields } : p))
    });
  }

  const active = page.fields.find((f) => f.id === selected);

  return (
    <main>
      <Nav />
      <div className="mx-auto grid max-w-6xl gap-8 px-6 py-14 md:grid-cols-[1fr_320px]">
        <div>
          <div className="flex items-center justify-between">
            <h1 className="font-display text-2xl">{schema.title}</h1>
            <button
              onClick={addField}
              className="rounded-full bg-ink px-4 py-2 text-xs text-paper"
            >
              Add field
            </button>
          </div>

          <ul className="mt-6 divide-y divide-line rounded-xl border border-line">
            {page.fields.map((f) => (
              <li
                key={f.id}
                onClick={() => setSelected(f.id)}
                className={`flex cursor-pointer items-center justify-between px-4 py-3 ${
                  selected === f.id ? "bg-haze" : ""
                }`}
              >
                <div>
                  <p className="text-sm font-medium">{f.label}</p>
                  <p className="text-xs text-graphite">{f.type}</p>
                </div>
                <div className="flex items-center gap-2 text-xs text-graphite">
                  <button onClick={(e) => { e.stopPropagation(); reorder(f.id, -1); }}>↑</button>
                  <button onClick={(e) => { e.stopPropagation(); reorder(f.id, 1); }}>↓</button>
                  <button onClick={(e) => { e.stopPropagation(); duplicateField(f.id); }}>Duplicate</button>
                  <button
                    onClick={(e) => { e.stopPropagation(); removeField(f.id); }}
                    className="text-flag"
                  >
                    Delete
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <button
            onClick={() => router.push("/preview")}
            className="mt-8 rounded-full bg-ink px-6 py-3 text-sm text-paper hover:bg-graphite"
          >
            Continue to export
          </button>
        </div>

        <aside className="rounded-xl border border-line p-5">
          <p className="text-xs uppercase tracking-wide text-graphite">Field settings</p>
          {!active ? (
            <p className="mt-4 text-sm text-graphite">Select a field to edit it.</p>
          ) : (
            <div className="mt-4 space-y-4 text-sm">
              <label className="block">
                Label
                <input
                  value={active.label}
                  onChange={(e) => patchField(active.id, { label: e.target.value })}
                  className="mt-1 w-full rounded-md border border-line px-3 py-1.5"
                />
              </label>
              <label className="block">
                Type
                <select
                  value={active.type}
                  onChange={(e) => patchField(active.id, { type: e.target.value as FieldType })}
                  className="mt-1 w-full rounded-md border border-line px-3 py-1.5"
                >
                  {FIELD_TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                Value
                <input
                  value={active.value ?? ""}
                  onChange={(e) => patchField(active.id, { value: e.target.value })}
                  className="mt-1 w-full rounded-md border border-line px-3 py-1.5"
                />
              </label>
              <div className="grid grid-cols-2 gap-3">
                {(["x", "y", "width", "height"] as const).map((k) => (
                  <label key={k} className="block capitalize">
                    {k}
                    <input
                      type="number"
                      value={active.position[k]}
                      onChange={(e) =>
                        patchField(active.id, {
                          position: { ...active.position, [k]: Number(e.target.value) }
                        })
                      }
                      className="mt-1 w-full rounded-md border border-line px-3 py-1.5"
                    />
                  </label>
                ))}
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={active.required}
                  onChange={(e) => patchField(active.id, { required: e.target.checked })}
                />
                Required
              </label>
            </div>
          )}
        </aside>
      </div>
    </main>
  );
}
