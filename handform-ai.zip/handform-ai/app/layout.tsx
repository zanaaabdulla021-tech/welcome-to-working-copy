import type { Metadata } from "next";
import { FormSessionProvider } from "@/hooks/useFormSession";
import "./globals.css";

export const metadata: Metadata = {
  title: "HandForm AI — Turn handwritten forms into digital forms",
  description:
    "Scan an English handwritten paper form and let an AI agent recreate it as an editable digital form."
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-body antialiased">
        <FormSessionProvider>{children}</FormSessionProvider>
      </body>
    </html>
  );
}
