"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Nav } from "@/components/ui/Nav";
import { useFormSession } from "@/hooks/useFormSession";
import { exportFormToPdf, downloadBlob } from "@/lib/pdf/export";
import { saveForm } from "@/lib/storage";

export default function PreviewPage() {
  const router = useRouter();
  const { schema } = useFormSession();
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!schema) router.replace("/scan");
  }, [schema, router]);

  if (!schema) return null;
  const page = schema.pages[0];

  async function handleExport(mode: "completed" | "blank") {
    const blob = await exportFormToPdf(schema!, mode);
    downloadBlob(blob, `${schema!.title.replace(/\s+/g, "-").toLowerCase()}-${mode}.pdf`);
  }

  function handleSave() {
    saveForm(schema!);
    setSaved(true);
  }

  return (
    <main>
      <Nav />
      <div className="mx-auto max-w-3xl px-6 py-14">
        <h1 className="font-display text-3xl">Your digital form is ready</h1>
        <p className="mt-2 text-graphite">
          Review the final layout, then export or save it for later.
        </p>

        <div
          className="relative mt-8 w-full rounded-xl border border-line bg-white shadow-sm"
          style={{ aspectRatio: `${page.imageWidth} / ${page.imageHeight}` }}
        >
          <p className="absolute left-6 top-4 font-display text-lg">{schema.title}</p>
          {page.fields.map((f) => (
            <div
              key={f.id}
              className="absolute"
              style={{
                left: `${(f.position.x / page.imageWidth) * 100}%`,
                top: `${(f.position.y / page.imageHeight) * 100}%`,
                width: `${(f.position.width / page.imageWidth) * 100}%`
              }}
            >
              <p className="text-[10px] text-graphite">{f.label}</p>
              <div className="field-line pb-1 text-xs">{f.value ?? ""}</div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => handleExport("completed")}
            className="rounded-full bg-ink px-6 py-3 text-sm text-paper hover:bg-graphite"
          >
            Export completed form
          </button>
          <button
            onClick={() => handleExport("blank")}
            className="rounded-full border border-line px-6 py-3 text-sm hover:border-ink"
          >
            Export blank form
          </button>
          <button
            onClick={() => window.print()}
            className="rounded-full border border-line px-6 py-3 text-sm hover:border-ink"
          >
            Print
          </button>
          <button
            onClick={handleSave}
            className="rounded-full border border-line px-6 py-3 text-sm hover:border-ink"
          >
            {saved ? "Saved ✓" : "Save locally"}
          </button>
        </div>
      </div>
    </main>
  );
}
