import Link from "next/link";
import { Nav } from "@/components/ui/Nav";

const steps = [
  {
    n: "Scan",
    title: "Photograph the paper form",
    body: "Use the camera scanner or drop in a photo, image, or PDF. Edges, shadows, and skew are corrected automatically."
  },
  {
    n: "Read",
    title: "The agent reads it",
    body: "English handwriting, printed text, checkboxes, and signatures are recognized field by field — never guessed when unclear."
  },
  {
    n: "Rebuild",
    title: "A digital form is reconstructed",
    body: "Labels, sections, tables, and field types are inferred automatically. Nothing is rebuilt by hand."
  },
  {
    n: "Confirm",
    title: "You review what's uncertain",
    body: "Low-confidence fields are flagged for a quick look. Everything else is already done."
  }
];

const capabilities = [
  { title: "English handwriting recognition", body: "Names, dates, addresses, phone numbers, short answers, and check marks — read field by field with a confidence score attached to each one." },
  { title: "Automatic form reconstruction", body: "The original layout — sections, tables, spacing, checkboxes — is rebuilt as an editable form, not redrawn from scratch." },
  { title: "Smart field detection", body: "The agent decides whether a line is a text input, a date, a phone number, or a radio group, the same way a person reading the page would." },
  { title: "Review & correction", body: "Uncertain fields are surfaced with the AI's best guess and a confidence score, so you only touch what needs touching." },
  { title: "PDF export", body: "Export the completed form, or a blank version of the reconstructed template, as a properly laid-out A4 PDF." },
  { title: "Mobile scanner", body: "A document-scanner camera flow with edge detection, capture, retake, and perspective correction, built for the phone in your hand." }
];

export default function LandingPage() {
  return (
    <main>
      <Nav />

      <section className="mx-auto max-w-5xl px-6 pb-20 pt-16 md:pt-24">
        <div className="max-w-2xl">
          <p className="text-sm text-signal">Form Reconstruction Agent</p>
          <h1 className="mt-4 font-display text-4xl leading-tight text-ink md:text-6xl">
            Turn handwritten forms into digital forms
          </h1>
          <p className="mt-6 text-lg text-graphite">
            Scan an English handwritten paper form and let an AI agent read
            it, understand it, and rebuild it as an editable digital form —
            no database, nothing stored on a server.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/scan"
              className="rounded-full bg-ink px-6 py-3 text-paper hover:bg-graphite"
            >
              Scan a form
            </Link>
            <Link
              href="/scan?demo=1"
              className="rounded-full border border-line px-6 py-3 text-ink hover:border-ink"
            >
              Try demo
            </Link>
          </div>
        </div>
      </section>

      <section className="border-t border-line bg-haze/60">
        <div className="mx-auto max-w-5xl px-6 py-16">
          <h2 className="font-display text-2xl">How it works</h2>
          <div className="mt-10 grid gap-8 md:grid-cols-4">
            {steps.map((s) => (
              <div key={s.n} className="border-l border-line pl-4">
                <p className="font-mono text-xs text-signal">{s.n}</p>
                <p className="mt-2 font-display text-lg">{s.title}</p>
                <p className="mt-2 text-sm text-graphite">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-16">
        <h2 className="font-display text-2xl">What the agent does</h2>
        <div className="mt-10 grid gap-x-10 gap-y-10 md:grid-cols-2">
          {capabilities.map((c) => (
            <div key={c.title} className="field-line pb-6">
              <p className="font-display text-lg">{c.title}</p>
              <p className="mt-2 text-sm text-graphite">{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-line py-10 text-center text-sm text-graphite">
        HandForm AI — runs entirely on your device and your own AI provider.
      </footer>
    </main>
  );
}
