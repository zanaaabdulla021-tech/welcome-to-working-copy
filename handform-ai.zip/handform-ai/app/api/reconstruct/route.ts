import { NextRequest, NextResponse } from "next/server";
import { runFormReconstructionAgent } from "@/lib/agents/formReconstructionAgent";

// Server-side route: this is the only place an AI provider (mock or real)
// gets invoked, and the only place AI_API_KEY is ever read.
export async function POST(req: NextRequest) {
  try {
    const { imageDataUrl } = await req.json();
    if (typeof imageDataUrl !== "string" || !imageDataUrl.startsWith("data:")) {
      return NextResponse.json(
        { error: "We couldn't detect a form in this image. Please upload a clearer document." },
        { status: 400 }
      );
    }

    const result = await runFormReconstructionAgent(imageDataUrl);
    return NextResponse.json(result);
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "The form could not be reconstructed. Please try again." },
      { status: 500 }
    );
  }
}
