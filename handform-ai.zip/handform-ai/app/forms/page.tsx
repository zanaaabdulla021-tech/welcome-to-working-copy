"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Nav } from "@/components/ui/Nav";
import { SavedFormMeta } from "@/types/form";
import { listSavedForms, deleteForm, duplicateForm, renameForm, loadForm } from "@/lib/storage";
import { useFormSession } from "@/hooks/useFormSession";
import { exportFormToPdf, downloadBlob } from "@/lib/pdf/export";

export default function FormsPage() {
  const [forms, setForms] = useState<SavedFormMeta[]>([]);
  const { setSchema } = useFormSession();
  const router = useRouter();

  useEffect(() => {
    setForms(listSavedForms());
  }, []);

  function refresh() {
    setForms(listSavedForms());
  }

  return (
    <main>
      <Nav />
      <div className="mx-auto max-w-4xl px-6 py-14">
        <h1 className="font-display text-3xl">Saved forms</h1>
        <p className="mt-2 text-graphite">
          Stored only in this browser's LocalStorage — nothing leaves your device.
        </p>

        {forms.length === 0 ? (
          <p className="mt-10 text-sm text-graphite">
            Nothing saved yet. Scan a form and choose "Save locally" from the export screen.
          </p>
        ) : (
          <ul className="mt-8 divide-y divide-line rounded-xl border border-line">
            {forms.map((f) => (
              <li key={f.id} className="flex items-center justify-between px-5 py-4">
                <div>
                  <p className="font-medium">{f.title}</p>
                  <p className="text-xs text-graphite">
                    {f.fieldCount} fields · updated {new Date(f.updatedAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2 text-xs text-graphite">
                  <button
                    onClick={() => {
                      const schema = loadForm(f.id);
                      if (schema) {
                        setSchema(schema);
                        router.push("/editor");
                      }
                    }}
                  >
                    Open
                  </button>
                  <button
                    onClick={() => {
                      const name = prompt("Rename form", f.title);
                      if (name) {
                        renameForm(f.id, name);
                        refresh();
                      }
                    }}
                  >
                    Rename
                  </button>
                  <button
                    onClick={() => {
                      duplicateForm(f.id);
                      refresh();
                    }}
                  >
                    Duplicate
                  </button>
                  <button
                    onClick={async () => {
                      const schema = loadForm(f.id);
                      if (schema) downloadBlob(await exportFormToPdf(schema), `${f.title}.pdf`);
                    }}
                  >
                    Export
                  </button>
                  <button
                    className="text-flag"
                    onClick={() => {
                      deleteForm(f.id);
                      refresh();
                    }}
                  >
                    Delete
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
