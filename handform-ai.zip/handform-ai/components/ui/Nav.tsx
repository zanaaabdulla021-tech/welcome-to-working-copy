import Link from "next/link";

export function Nav() {
  return (
    <header className="border-b border-line">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
        <Link href="/" className="font-display text-lg tracking-tight">
          HandForm <span className="text-signal">AI</span>
        </Link>
        <nav className="flex items-center gap-6 text-sm text-graphite">
          <Link href="/forms" className="hover:text-ink">
            Saved forms
          </Link>
          <Link
            href="/scan"
            className="rounded-full bg-ink px-4 py-2 text-paper hover:bg-graphite"
          >
            Scan a form
          </Link>
        </nav>
      </div>
    </header>
  );
}
