"use client";

import { useState } from "react";
import { FormSchema } from "@/types/form";

interface Props {
  image: string;
  schema: FormSchema;
}

// Original vs. Digital comparison, with an overlay mode (adjustable
// opacity) so the reconstruction can be checked against the scan directly.
export function CompareView({ image, schema }: Props) {
  const [mode, setMode] = useState<"side" | "overlay">("side");
  const [opacity, setOpacity] = useState(0.6);
  const page = schema.pages[0];

  return (
    <div>
      <div className="flex items-center gap-2 text-sm">
        {(["side", "overlay"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`rounded-full px-4 py-1.5 ${
              mode === m ? "bg-ink text-paper" : "border border-line text-graphite"
            }`}
          >
            {m === "side" ? "Side by side" : "Overlay"}
          </button>
        ))}
        {mode === "overlay" && (
          <label className="ml-4 flex items-center gap-2 text-graphite">
            Opacity
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={opacity}
              onChange={(e) => setOpacity(Number(e.target.value))}
            />
          </label>
        )}
      </div>

      {mode === "side" ? (
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Panel title="Original scan">
            <img src={image} alt="Original scan" className="w-full rounded-lg" />
          </Panel>
          <Panel title="Digital form">
            <FieldOverlay page={page} opacity={1} />
          </Panel>
        </div>
      ) : (
        <div className="relative mt-4 overflow-hidden rounded-lg border border-line">
          <img src={image} alt="Original scan" className="w-full" />
          <div className="absolute inset-0" style={{ opacity }}>
            <FieldOverlay page={page} opacity={1} transparent />
          </div>
        </div>
      )}
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-2 text-xs uppercase tracking-wide text-graphite">{title}</p>
      <div className="rounded-lg border border-line bg-white p-2">{children}</div>
    </div>
  );
}

function FieldOverlay({
  page,
  opacity,
  transparent
}: {
  page: FormSchema["pages"][number];
  opacity: number;
  transparent?: boolean;
}) {
  return (
    <div
      className="relative w-full"
      style={{
        aspectRatio: `${page.imageWidth} / ${page.imageHeight}`,
        background: transparent ? "transparent" : "#fff",
        opacity
      }}
    >
      {page.fields.map((f) => (
        <div
          key={f.id}
          className={`absolute rounded border text-[10px] leading-tight ${
            f.needsReview ? "border-flag bg-flag/10" : "border-signal bg-signal/5"
          }`}
          style={{
            left: `${(f.position.x / page.imageWidth) * 100}%`,
            top: `${(f.position.y / page.imageHeight) * 100}%`,
            width: `${(f.position.width / page.imageWidth) * 100}%`,
            height: `${(f.position.height / page.imageHeight) * 100}%`
          }}
        >
          <span className="block truncate px-1 text-graphite">{f.label}</span>
        </div>
      ))}
    </div>
  );
}
