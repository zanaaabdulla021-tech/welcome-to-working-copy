"use client";

import { useEffect, useRef, useState } from "react";

interface Props {
  onCapture: (dataUrl: string) => void;
  onError: (message: string) => void;
}

// Document-scanner camera flow: live preview with a page-frame guide,
// capture, and retake. Perspective correction happens downstream in
// lib/image-processing/enhance.ts once a frame is captured.
export function CameraScanner({ onCapture, onError }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [ready, setReady] = useState(false);
  const [captured, setCaptured] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: "environment" } })
      .then((s) => {
        stream = s;
        if (videoRef.current) {
          videoRef.current.srcObject = s;
          setReady(true);
        }
      })
      .catch(() =>
        onError(
          "Camera access wasn't available. You can upload a photo instead."
        )
      );
    return () => stream?.getTracks().forEach((t) => t.stop());
  }, [onError]);

  function capture() {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx?.drawImage(video, 0, 0);
    setCaptured(canvas.toDataURL("image/jpeg", 0.95));
  }

  if (captured) {
    return (
      <div className="flex flex-col items-center gap-4">
        <img src={captured} alt="Captured form" className="max-h-[60vh] rounded-xl border border-line" />
        <div className="flex gap-3">
          <button
            onClick={() => setCaptured(null)}
            className="rounded-full border border-line px-5 py-2 text-sm hover:border-ink"
          >
            Retake
          </button>
          <button
            onClick={() => onCapture(captured)}
            className="rounded-full bg-ink px-5 py-2 text-sm text-paper hover:bg-graphite"
          >
            Use this photo
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative w-full max-w-xl overflow-hidden rounded-xl bg-ink">
        <video ref={videoRef} autoPlay playsInline muted className="w-full" />
        <div className="pointer-events-none absolute inset-6 rounded-lg border-2 border-paper/70" />
      </div>
      <button
        disabled={!ready}
        onClick={capture}
        className="rounded-full bg-ink px-6 py-3 text-paper disabled:opacity-40"
      >
        Capture
      </button>
    </div>
  );
}
