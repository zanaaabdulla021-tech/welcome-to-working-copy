"use client";

import { useCallback, useRef, useState } from "react";
import { fileToDataUrl, pdfFirstPageToImage } from "@/lib/image-processing/pdfToImage";

interface Props {
  onImageReady: (dataUrl: string) => void;
  onError: (message: string) => void;
}

const ACCEPTED = ["image/jpeg", "image/png", "image/webp", "application/pdf"];

export function UploadDropzone({ onImageReady, onError }: Props) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    async (file: File) => {
      if (!ACCEPTED.includes(file.type)) {
        onError("That file type isn't supported. Use a JPG, PNG, WEBP, or PDF.");
        return;
      }
      try {
        const dataUrl =
          file.type === "application/pdf"
            ? await pdfFirstPageToImage(file)
            : await fileToDataUrl(file);
        onImageReady(dataUrl);
      } catch {
        onError("We couldn't read that file. Please try a different one.");
      }
    },
    [onImageReady, onError]
  );

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file) handleFile(file);
      }}
      onClick={() => inputRef.current?.click()}
      className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-16 text-center transition-colors ${
        dragging ? "border-signal bg-signal/5" : "border-line hover:border-graphite"
      }`}
    >
      <p className="font-display text-xl">Drop a form here</p>
      <p className="mt-2 text-sm text-graphite">
        JPG, PNG, WEBP, or PDF — or click to browse
      </p>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED.join(",")}
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
      />
    </div>
  );
}
