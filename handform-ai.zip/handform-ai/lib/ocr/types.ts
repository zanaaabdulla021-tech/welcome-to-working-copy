import { RecognizedValue, BoundingBox } from "@/types/form";

// Printed + handwritten English recognition. Never invents text for
// unreadable regions — low-confidence reads come back with text: null
// and needsReview: true instead of a guess.
export interface HandwritingProvider {
  recognizeRegion(
    imageDataUrl: string,
    bbox: BoundingBox
  ): Promise<RecognizedValue>;
}

export interface OCRProvider {
  recognizePrinted(
    imageDataUrl: string,
    bbox: BoundingBox
  ): Promise<RecognizedValue>;
}
