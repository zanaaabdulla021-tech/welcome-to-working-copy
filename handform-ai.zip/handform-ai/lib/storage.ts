"use client";

import { FormSchema, SavedFormMeta } from "@/types/form";

// LocalStorage only, per the no-database requirement. Metadata + form JSON
// live here; original scan images (which can be large) go to IndexedDB
// instead so LocalStorage never chokes on a multi-megabyte photo.
const INDEX_KEY = "handform:index";
const FORM_PREFIX = "handform:form:";

export function listSavedForms(): SavedFormMeta[] {
  if (typeof window === "undefined") return [];
  const raw = window.localStorage.getItem(INDEX_KEY);
  return raw ? (JSON.parse(raw) as SavedFormMeta[]) : [];
}

export function saveForm(schema: FormSchema): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(FORM_PREFIX + schema.id, JSON.stringify(schema));
  const index = listSavedForms().filter((m) => m.id !== schema.id);
  index.unshift({
    id: schema.id,
    title: schema.title,
    updatedAt: schema.updatedAt,
    fieldCount: schema.pages.reduce((n, p) => n + p.fields.length, 0)
  });
  window.localStorage.setItem(INDEX_KEY, JSON.stringify(index));
}

export function loadForm(id: string): FormSchema | null {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem(FORM_PREFIX + id);
  return raw ? (JSON.parse(raw) as FormSchema) : null;
}

export function deleteForm(id: string): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(FORM_PREFIX + id);
  const index = listSavedForms().filter((m) => m.id !== id);
  window.localStorage.setItem(INDEX_KEY, JSON.stringify(index));
}

export function renameForm(id: string, title: string): void {
  const schema = loadForm(id);
  if (!schema) return;
  saveForm({ ...schema, title, updatedAt: new Date().toISOString() });
}

export function duplicateForm(id: string): FormSchema | null {
  const schema = loadForm(id);
  if (!schema) return null;
  const copy: FormSchema = {
    ...schema,
    id: crypto.randomUUID(),
    title: `${schema.title} (Copy)`,
    updatedAt: new Date().toISOString()
  };
  saveForm(copy);
  return copy;
}

// --- IndexedDB, for the original scan image only ---
const DB_NAME = "handform-images";
const STORE = "images";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveImage(key: string, dataUrl: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(dataUrl, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadImage(key: string): Promise<string | null> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).get(key);
    req.onsuccess = () => resolve((req.result as string) ?? null);
    req.onerror = () => reject(req.error);
  });
}
