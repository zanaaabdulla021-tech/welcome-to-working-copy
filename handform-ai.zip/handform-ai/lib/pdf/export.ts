"use client";

import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { FormSchema } from "@/types/form";

// A4 at 72dpi points.
const PAGE_W = 595.28;
const PAGE_H = 841.89;

export async function exportFormToPdf(
  schema: FormSchema,
  mode: "completed" | "blank" = "completed"
): Promise<Blob> {
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  for (const p of schema.pages) {
    const page = pdf.addPage([PAGE_W, PAGE_H]);
    const scaleX = PAGE_W / p.imageWidth;
    const scaleY = PAGE_H / p.imageHeight;

    page.drawText(schema.title, {
      x: 40,
      y: PAGE_H - 40,
      size: 16,
      font: bold,
      color: rgb(0.08, 0.09, 0.1)
    });

    for (const field of p.fields) {
      const x = field.position.x * scaleX + 40;
      const yTop = PAGE_H - field.position.y * scaleY - 60;

      page.drawText(field.label, {
        x,
        y: yTop,
        size: 9,
        font,
        color: rgb(0.35, 0.37, 0.4)
      });

      if (field.type !== "signature") {
        page.drawLine({
          start: { x, y: yTop - 14 },
          end: { x: x + field.position.width * scaleX, y: yTop - 14 },
          thickness: 0.75,
          color: rgb(0.75, 0.73, 0.68)
        });
      } else {
        page.drawRectangle({
          x,
          y: yTop - 40,
          width: field.position.width * scaleX,
          height: 34,
          borderColor: rgb(0.75, 0.73, 0.68),
          borderWidth: 0.75
        });
      }

      if (mode === "completed" && field.value) {
        page.drawText(String(field.value), {
          x,
          y: yTop - 12,
          size: 11,
          font,
          color: rgb(0.08, 0.09, 0.1)
        });
      }
    }
  }

  const bytes = await pdf.save();
  return new Blob([bytes.buffer as ArrayBuffer], { type: "application/pdf" });
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
