import { BoundingBox } from "@/types/form";

export interface DetectedRegion {
  kind:
    | "section"
    | "table"
    | "row"
    | "column"
    | "label"
    | "line"
    | "checkbox"
    | "radio"
    | "signature"
    | "handwritten"
    | "printed";
  bbox: BoundingBox;
}

export interface DocumentAnalysis {
  pageWidth: number;
  pageHeight: number;
  regions: DetectedRegion[];
}

// See -> Understand starts here. A real implementation calls a
// vision-capable model; this interface is what lets that swap happen
// without touching any calling code.
export interface VisionProvider {
  analyzeDocument(imageDataUrl: string): Promise<DocumentAnalysis>;
}

export interface EnhancementResult {
  originalDataUrl: string;
  enhancedDataUrl: string;
  appliedSteps: string[];
}

export interface ImageEnhancer {
  enhance(imageDataUrl: string): Promise<EnhancementResult>;
}
