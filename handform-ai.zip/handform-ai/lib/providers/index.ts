import { VisionProvider } from "@/lib/vision/types";
import { FormReasoningProvider } from "@/lib/forms/types";
import { MockVisionProvider, MockFormReasoningProvider } from "./mock";
import { AnthropicVisionProvider, AnthropicFormReasoningProvider } from "./anthropic";

// Single switch point. Server-only (imported from app/api routes).
// Presence of AI_API_KEY decides real vs. mock — nothing else in the
// app needs to know which one is active.
export function getVisionProvider(): VisionProvider {
  return process.env.AI_API_KEY
    ? new AnthropicVisionProvider()
    : new MockVisionProvider();
}

export function getFormReasoningProvider(): FormReasoningProvider {
  return process.env.AI_API_KEY
    ? new AnthropicFormReasoningProvider()
    : new MockFormReasoningProvider();
}
