import { VisionProvider, DocumentAnalysis } from "@/lib/vision/types";
import { FormReasoningProvider } from "@/lib/forms/types";
import { FormSchema, ValidationResult } from "@/types/form";

// Real provider. Only ever imported from server code (app/api/* routes) —
// AI_API_KEY must never reach a client bundle. This calls the standard
// Anthropic /v1/messages endpoint with the scan as an image block and asks
// for strict JSON matching our schema types.
const API_URL = "https://api.anthropic.com/v1/messages";

async function callModel(system: string, imageDataUrl: string, prompt: string) {
  const apiKey = process.env.AI_API_KEY;
  if (!apiKey) throw new Error("AI_API_KEY not configured");

  const [, mediaType, base64] =
    imageDataUrl.match(/^data:(.+);base64,(.+)$/) ?? [];
  if (!base64) throw new Error("Expected a base64 data URL");

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 4000,
      system,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: mediaType, data: base64 }
            },
            { type: "text", text: prompt }
          ]
        }
      ]
    })
  });

  if (!res.ok) {
    throw new Error(`AI provider request failed: ${res.status}`);
  }
  const data = await res.json();
  const text = (data.content ?? [])
    .map((block: { type: string; text?: string }) =>
      block.type === "text" ? block.text ?? "" : ""
    )
    .join("");
  const cleaned = text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

export class AnthropicVisionProvider implements VisionProvider {
  async analyzeDocument(imageDataUrl: string): Promise<DocumentAnalysis> {
    return callModel(
      "You are the layout-analysis stage of a form-reconstruction agent. " +
        "Respond with ONLY a JSON object matching { pageWidth, pageHeight, regions: [{ kind, bbox:{x,y,width,height} }] }. " +
        "kind is one of: section, table, row, column, label, line, checkbox, radio, signature, handwritten, printed. " +
        "No prose, no markdown fences.",
      imageDataUrl,
      "Analyze this scanned paper form and return the region layout JSON."
    );
  }
}

export class AnthropicFormReasoningProvider implements FormReasoningProvider {
  async reconstruct(
    _analysis: DocumentAnalysis,
    imageDataUrl: string
  ): Promise<FormSchema> {
    return callModel(
      "You are the understand+reconstruct stage of a form-reconstruction agent for ENGLISH-only paper forms. " +
        "Read every printed and handwritten field. Never invent unreadable handwriting: if unclear, set value to null, " +
        "confidence low, and needsReview true. Respond with ONLY JSON matching the FormSchema type: " +
        "{ id, title, language:'en', createdAt, updatedAt, pages:[{ page, imageWidth, imageHeight, fields:[{ id, label, type, value, confidence, required, position:{x,y,width,height}, options?, needsReview? }]}] }. " +
        "type is one of: text, textarea, number, email, phone, date, time, checkbox, radio, select, signature. No prose.",
      imageDataUrl,
      "Reconstruct this paper form as a digital form schema."
    );
  }

  async validate(
    schema: FormSchema,
    imageDataUrl: string
  ): Promise<ValidationResult> {
    return callModel(
      "You are the validation stage of a form-reconstruction agent. Compare the reconstructed form JSON against the " +
        "original scan image and return ONLY JSON matching { valid, score, issues:[{ fieldId, field, type, confidence?, detail? }] }. " +
        "type is one of: missing_field, incorrect_label, wrong_type, incorrect_handwriting, missing_checkbox, " +
        "incorrect_checkbox_state, missing_table, incorrect_layout, low_confidence.",
      imageDataUrl,
      `Reconstructed form JSON:\n${JSON.stringify(schema)}\n\nValidate it against the image.`
    );
  }
}
