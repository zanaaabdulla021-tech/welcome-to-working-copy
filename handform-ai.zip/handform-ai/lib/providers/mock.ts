import { v4 as uuid } from "uuid";
import { VisionProvider, DocumentAnalysis } from "@/lib/vision/types";
import { FormReasoningProvider } from "@/lib/forms/types";
import { FormSchema, ValidationResult, FormField } from "@/types/form";

// Deterministic, no-network fallback used whenever AI_API_KEY is not
// configured (see lib/providers/index.ts). It lets every screen in the
// product be exercised end-to-end today. Swap in lib/providers/anthropic.ts
// by setting AI_API_KEY — no calling code changes.
export class MockVisionProvider implements VisionProvider {
  async analyzeDocument(): Promise<DocumentAnalysis> {
    return {
      pageWidth: 1000,
      pageHeight: 1300,
      regions: [
        { kind: "label", bbox: { x: 80, y: 120, width: 200, height: 40 } },
        { kind: "line", bbox: { x: 300, y: 140, width: 500, height: 2 } },
        { kind: "label", bbox: { x: 80, y: 200, width: 200, height: 40 } },
        { kind: "line", bbox: { x: 300, y: 220, width: 300, height: 2 } },
        { kind: "checkbox", bbox: { x: 80, y: 280, width: 24, height: 24 } },
        { kind: "checkbox", bbox: { x: 220, y: 280, width: 24, height: 24 } },
        { kind: "signature", bbox: { x: 80, y: 900, width: 400, height: 80 } }
      ]
    };
  }
}

export class MockFormReasoningProvider implements FormReasoningProvider {
  async reconstruct(analysis: DocumentAnalysis): Promise<FormSchema> {
    const now = new Date().toISOString();
    const fields: FormField[] = [
      field("Full Name", "text", "Jon Sm?th", 0.51, {
        x: 300,
        y: 110,
        width: 400,
        height: 50
      }, true),
      field("Date of Birth", "date", "1990-04-12", 0.94, {
        x: 300,
        y: 190,
        width: 300,
        height: 50
      }),
      field("Phone Number", "phone", "(555) 019-2231", 0.89, {
        x: 300,
        y: 270,
        width: 300,
        height: 50
      }),
      field("Gender", "radio", "Male", 0.97, {
        x: 80,
        y: 270,
        width: 260,
        height: 40
      }),
      field("Signature", "signature", null, 0.4, {
        x: 80,
        y: 900,
        width: 400,
        height: 80
      }, true)
    ];
    (fields[3].options = [
      { id: uuid(), label: "Male", checked: true },
      { id: uuid(), label: "Female", checked: false }
    ]);

    return {
      id: uuid(),
      title: "Employee Application",
      language: "en",
      createdAt: now,
      updatedAt: now,
      pages: [
        {
          page: 1,
          imageWidth: analysis.pageWidth,
          imageHeight: analysis.pageHeight,
          fields
        }
      ]
    };
  }

  async validate(schema: FormSchema): Promise<ValidationResult> {
    const issues = schema.pages
      .flatMap((p) => p.fields)
      .filter((f) => f.confidence < 0.6)
      .map((f) => ({
        fieldId: f.id,
        field: f.label,
        type: "low_confidence" as const,
        confidence: f.confidence
      }));

    const score = issues.length === 0 ? 0.97 : 0.72;
    return { valid: issues.length === 0, score, issues };
  }
}

function field(
  label: string,
  type: FormField["type"],
  value: string | null,
  confidence: number,
  position: FormField["position"],
  needsReview = false
): FormField {
  return {
    id: uuid(),
    label,
    type,
    value,
    confidence,
    required: true,
    position,
    needsReview: needsReview || confidence < 0.6
  };
}
