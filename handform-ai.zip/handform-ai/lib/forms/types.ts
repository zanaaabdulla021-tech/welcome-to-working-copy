import { DocumentAnalysis } from "@/lib/vision/types";
import { FormSchema, ValidationResult } from "@/types/form";

// Understand -> Reconstruct. Turns detected regions + recognized text
// into a typed, labeled form schema (field types, required-ness,
// grouping of radios/checkboxes, table structure).
export interface FormReasoningProvider {
  reconstruct(
    analysis: DocumentAnalysis,
    imageDataUrl: string
  ): Promise<FormSchema>;

  validate(schema: FormSchema, imageDataUrl: string): Promise<ValidationResult>;
}
