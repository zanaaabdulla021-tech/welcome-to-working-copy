import { getVisionProvider, getFormReasoningProvider } from "@/lib/providers";
import { FormSchema, ValidationResult, ValidationIssue } from "@/types/form";

const MAX_REPAIR_CYCLES = 3;

export interface AgentResult {
  schema: FormSchema;
  validation: ValidationResult;
  cycles: number;
}

// See -> Understand -> Extract -> Reconstruct -> Validate -> Repair -> Return.
// This is the one place that owns the full pipeline; UI code only ever
// calls runFormReconstructionAgent and renders the result.
export async function runFormReconstructionAgent(
  imageDataUrl: string
): Promise<AgentResult> {
  const vision = getVisionProvider();
  const reasoning = getFormReasoningProvider();

  const analysis = await vision.analyzeDocument(imageDataUrl);
  let schema = await reasoning.reconstruct(analysis, imageDataUrl);
  let validation = await reasoning.validate(schema, imageDataUrl);

  let cycles = 0;
  while (!validation.valid && cycles < MAX_REPAIR_CYCLES) {
    schema = repairSchema(schema, validation.issues);
    validation = await reasoning.validate(schema, imageDataUrl);
    cycles += 1;
  }

  return { schema, validation, cycles };
}

// Flags the offending fields for human review rather than looping forever
// or guessing a replacement value — repair here means "hand this to the
// reviewer," never "invent a value."
function repairSchema(
  schema: FormSchema,
  issues: ValidationIssue[]
): FormSchema {
  const flagged = new Set(issues.map((i) => i.fieldId));
  return {
    ...schema,
    updatedAt: new Date().toISOString(),
    pages: schema.pages.map((page) => ({
      ...page,
      fields: page.fields.map((f) =>
        flagged.has(f.id) ? { ...f, needsReview: true } : f
      )
    }))
  };
}
