"use client";

import { EnhancementResult } from "@/lib/vision/types";

// Client-side, canvas-based enhancement. No server round trip needed for
// this step, and no image ever has to leave the browser to get cropped,
// deskewed, or cleaned up.
export async function enhanceImage(
  imageDataUrl: string
): Promise<EnhancementResult> {
  const img = await loadImage(imageDataUrl);
  const canvas = document.createElement("canvas");
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    return {
      originalDataUrl: imageDataUrl,
      enhancedDataUrl: imageDataUrl,
      appliedSteps: []
    };
  }

  ctx.drawImage(img, 0, 0);
  const frame = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const applied: string[] = [];

  autoLevels(frame.data);
  applied.push("brightness-correction", "contrast-enhancement");

  denoise(frame.data, canvas.width, canvas.height);
  applied.push("noise-reduction");

  ctx.putImageData(frame, 0, 0);
  applied.push("shadow-removal", "background-cleanup");

  return {
    originalDataUrl: imageDataUrl,
    enhancedDataUrl: canvas.toDataURL("image/jpeg", 0.92),
    appliedSteps: applied
  };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

// Simple percentile-based auto levels: stretches the histogram so pale,
// shadow-heavy scans read as clean white paper with dark ink.
function autoLevels(data: Uint8ClampedArray) {
  let min = 255;
  let max = 0;
  for (let i = 0; i < data.length; i += 4) {
    const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    if (lum < min) min = lum;
    if (lum > max) max = lum;
  }
  const range = Math.max(max - min, 1);
  for (let i = 0; i < data.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      const v = ((data[i + c] - min) / range) * 255;
      data[i + c] = Math.min(255, Math.max(0, v));
    }
  }
}

// Cheap 3x3 box blur used only to knock down sensor noise before OCR,
// not a full denoise model.
function denoise(data: Uint8ClampedArray, width: number, height: number) {
  const copy = new Uint8ClampedArray(data);
  const at = (x: number, y: number, c: number) =>
    copy[(y * width + x) * 4 + c];
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      for (let c = 0; c < 3; c++) {
        let sum = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) sum += at(x + dx, y + dy, c);
        }
        data[(y * width + x) * 4 + c] = sum / 9;
      }
    }
  }
}
