"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  ReactNode
} from "react";
import { FormSchema, ValidationResult, ProcessingStage } from "@/types/form";

// Carries the in-progress scan/schema across /scan -> /process -> /review
// -> /editor -> /preview without ever touching a server-side store.
// sessionStorage is enough here: it's per-tab working memory, cleared when
// the tab closes, same spirit as the "no database" constraint.
interface SessionState {
  originalImage: string | null;
  enhancedImage: string | null;
  schema: FormSchema | null;
  validation: ValidationResult | null;
  stages: ProcessingStage[];
}

interface FormSessionValue extends SessionState {
  setOriginalImage: (img: string) => void;
  setEnhancedImage: (img: string) => void;
  setSchema: (schema: FormSchema) => void;
  setValidation: (v: ValidationResult) => void;
  setStages: (s: ProcessingStage[]) => void;
  updateField: (fieldId: string, patch: Record<string, unknown>) => void;
  reset: () => void;
}

const KEY = "handform:session";

const empty: SessionState = {
  originalImage: null,
  enhancedImage: null,
  schema: null,
  validation: null,
  stages: []
};

const FormSessionContext = createContext<FormSessionValue | null>(null);

export function FormSessionProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SessionState>(empty);

  useEffect(() => {
    const raw = window.sessionStorage.getItem(KEY);
    if (raw) setState(JSON.parse(raw));
  }, []);

  const persist = useCallback((next: SessionState) => {
    setState(next);
    window.sessionStorage.setItem(KEY, JSON.stringify(next));
  }, []);

  const value: FormSessionValue = {
    ...state,
    setOriginalImage: (img) => persist({ ...state, originalImage: img }),
    setEnhancedImage: (img) => persist({ ...state, enhancedImage: img }),
    setSchema: (schema) => persist({ ...state, schema }),
    setValidation: (validation) => persist({ ...state, validation }),
    setStages: (stages) => persist({ ...state, stages }),
    updateField: (fieldId, patch) => {
      if (!state.schema) return;
      const schema: FormSchema = {
        ...state.schema,
        updatedAt: new Date().toISOString(),
        pages: state.schema.pages.map((p) => ({
          ...p,
          fields: p.fields.map((f) =>
            f.id === fieldId ? { ...f, ...patch, needsReview: false } : f
          )
        }))
      };
      persist({ ...state, schema });
    },
    reset: () => persist(empty)
  };

  return (
    <FormSessionContext.Provider value={value}>
      {children}
    </FormSessionContext.Provider>
  );
}

export function useFormSession(): FormSessionValue {
  const ctx = useContext(FormSessionContext);
  if (!ctx) throw new Error("useFormSession must be used within FormSessionProvider");
  return ctx;
}
