// Core domain types shared across the app. Nothing here touches a database —
// this schema is what gets held in React state and, when the user opts in,
// serialized into LocalStorage / IndexedDB.

export type FieldType =
  | "text"
  | "textarea"
  | "number"
  | "email"
  | "phone"
  | "date"
  | "time"
  | "checkbox"
  | "radio"
  | "select"
  | "signature";

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface RecognizedValue {
  text: string | null;
  confidence: number;
  type: "handwritten" | "printed" | "mark";
  bbox: BoundingBox;
  needsReview?: boolean;
}

export interface FormFieldOption {
  id: string;
  label: string;
  checked?: boolean;
}

export interface FormField {
  id: string;
  label: string;
  type: FieldType;
  value: string | null;
  confidence: number;
  required: boolean;
  position: BoundingBox;
  options?: FormFieldOption[];
  needsReview?: boolean;
  raw?: RecognizedValue;
}

export interface FormPage {
  page: number;
  imageWidth: number;
  imageHeight: number;
  fields: FormField[];
}

export interface FormSchema {
  id: string;
  title: string;
  language: "en";
  createdAt: string;
  updatedAt: string;
  sourceImage?: string; // object URL / IndexedDB key, never a DB row
  pages: FormPage[];
}

export interface ValidationIssue {
  fieldId: string;
  field: string;
  type:
    | "missing_field"
    | "incorrect_label"
    | "wrong_type"
    | "incorrect_handwriting"
    | "missing_checkbox"
    | "incorrect_checkbox_state"
    | "missing_table"
    | "incorrect_layout"
    | "low_confidence";
  confidence?: number;
  detail?: string;
}

export interface ValidationResult {
  valid: boolean;
  score: number;
  issues: ValidationIssue[];
}

export interface ProcessingStage {
  id:
    | "detect"
    | "enhance"
    | "layout"
    | "handwriting"
    | "fields"
    | "understand"
    | "reconstruct"
    | "validate";
  label: string;
  status: "pending" | "active" | "done" | "error";
}

export interface SavedFormMeta {
  id: string;
  title: string;
  updatedAt: string;
  thumbnail?: string;
  fieldCount: number;
}
