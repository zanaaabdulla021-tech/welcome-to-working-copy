# HandForm AI

AI-powered form reconstruction. No database, anywhere.

## What's implemented (phases 1–11 of the build order)

- Project architecture: Next.js 14 (App Router) + TypeScript + Tailwind.
- Camera scanner + drag-and-drop upload (JPG/PNG/WEBP/PDF).
- Client-side image enhancement (auto levels, denoise) via Canvas.
- Form Reconstruction Agent (`lib/agents/formReconstructionAgent.ts`):
  See → Understand → Extract → Reconstruct → Validate → Repair (max 3 cycles) → Return.
- Swappable AI providers (`lib/providers`): a deterministic mock (works out of
  the box, no key needed) and a real Anthropic-vision-backed provider that
  activates the moment `AI_API_KEY` is set — no other code changes.
- Human review screen for low-confidence fields (Edit / Accept / Retry).
- Original-vs-digital comparison, including an opacity-adjustable overlay.
- Visual form editor: add/edit/move/resize/delete/duplicate/reorder fields,
  change field type, toggle required.
- PDF export (completed + blank) and browser print, built with `pdf-lib`.
- LocalStorage-backed "saved forms" dashboard (open/rename/duplicate/
  delete/export) — large images go to IndexedDB, never LocalStorage.
- Landing page.

No database, ORM, or DB driver is anywhere in this codebase. Search for
`prisma`, `mongodb`, `mysql`, `postgres`, `supabase`, or `firebase` — you
will find nothing.

## Running it

```bash
npm install
npm run dev
```

The app works immediately with the mock AI provider — every screen is
fully exercisable without any API key. To turn on real handwriting
recognition:

```bash
cp .env.example .env.local
# put a real Anthropic API key in AI_API_KEY
```

The key is only ever read server-side, inside `app/api/reconstruct/route.ts`
and `lib/providers/anthropic.ts`. It never reaches the client bundle.

## What to build next (phase 12 and beyond)

- Swap the mock's fixed sample fields for real per-image OCR bounding
  boxes once you're testing against your own scans — the mock exists to
  make the UI testable before wiring a key in, not as a permanent stand-in.
  With `AI_API_KEY` set, this already happens automatically.
- Drag-to-move / handle-to-resize directly on the field-overlay canvas
  (the editor currently edits position via numeric x/y/width/height).
- Multi-page form support end-to-end (the schema already supports it;
  the scan/upload flow currently digitizes page 1 only).
- Automated tests and a production build pass (phase 12).
